interface Vehicle {
    public String getNumberPlate();
    public String getColor();
    public String getModel();
}